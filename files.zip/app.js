// Personal Image Gallery (front-end simulation)
// - Signup / login stored in localStorage (for demo only)
// - Images stored as base64 data URLs in localStorage (be mindful of size limits)

// ---- Utilities ----
const LS_KEYS = {
  USERS: 'pg_users_v1',       // {username: {passwordHash, createdAt}}
  SESS: 'pg_session_v1',      // {username}
  IMAGES: (username) => `pg_images_v1:${username}` // array of {id,name,dataURL,createdAt}
};

const $ = (sel) => document.querySelector(sel);

// tiny helper to show alerts
function showAlert(msg, timeout = 3000) {
  const alerts = $('#alerts');
  if (!alerts) return;
  alerts.textContent = msg;
  setTimeout(() => {
    if (alerts.textContent === msg) alerts.textContent = '';
  }, timeout);
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2,8);
}

// Simple "hash" for demo (do NOT use in production). We're just obscuring the password locally.
function fakeHash(s) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return (h >>> 0).toString(36);
}

// ---- Auth ----
function loadUsers() {
  try {
    return JSON.parse(localStorage.getItem(LS_KEYS.USERS) || '{}');
  } catch (e) { return {}; }
}
function saveUsers(users) {
  localStorage.setItem(LS_KEYS.USERS, JSON.stringify(users));
}
function setSession(username) {
  localStorage.setItem(LS_KEYS.SESS, JSON.stringify({username, started: Date.now()}));
}
function clearSession() {
  localStorage.removeItem(LS_KEYS.SESS);
}
function getSession() {
  try { return JSON.parse(localStorage.getItem(LS_KEYS.SESS)); }
  catch (e) { return null; }
}

function signup(username, password) {
  const users = loadUsers();
  if (users[username]) return {ok:false, message:'Username already exists'};
  users[username] = { passwordHash: fakeHash(password), createdAt: new Date().toISOString() };
  saveUsers(users);
  return {ok:true};
}
function login(username, password) {
  const users = loadUsers();
  const u = users[username];
  if (!u) return {ok:false, message:'No such user'};
  if (u.passwordHash !== fakeHash(password)) return {ok:false, message:'Invalid password'};
  setSession(username);
  return {ok:true};
}

// ---- Images ----
function loadImages(username) {
  try {
    return JSON.parse(localStorage.getItem(LS_KEYS.IMAGES(username)) || '[]');
  } catch (e) { return []; }
}
function saveImages(username, arr) {
  localStorage.setItem(LS_KEYS.IMAGES(username), JSON.stringify(arr));
}

// ---- UI management ----
function showAuth(showSignup=false) {
  $('#auth').classList.remove('hidden');
  $('#gallerySection').classList.add('hidden');
  $('#authTitle').textContent = showSignup ? 'Create account' : 'Log in';
  $('#authSubmit').textContent = showSignup ? 'Create' : 'Log in';
  $('#toggleSignup').textContent = showSignup ? 'Back to log in' : 'Create account';
}
function showGalleryFor(username) {
  $('#auth').classList.add('hidden');
  $('#gallerySection').classList.remove('hidden');
  $('#user-area')?.classList?.remove('hidden');
  $('#welcome').textContent = `Hi ${username}`;
  renderGallery(username);
}

function renderGallery(username) {
  const gallery = $('#gallery');
  gallery.innerHTML = '';
  const images = loadImages(username).slice().reverse(); // newest first
  if (images.length === 0) {
    const el = document.createElement('div');
    el.className = 'muted';
    el.textContent = 'No images yet — upload using the button above.';
    gallery.appendChild(el);
    return;
  }

  images.forEach(img => {
    const item = document.createElement('div');
    item.className = 'gallery-item';
    const image = document.createElement('img');
    image.className = 'thumb';
    image.src = img.dataURL;
    image.alt = img.name || 'Image';
    image.loading = 'lazy';
    image.addEventListener('click', () => openModalFor(img));
    item.appendChild(image);

    const meta = document.createElement('div');
    meta.className = 'item-meta';
    const nameSpan = document.createElement('span');
    nameSpan.textContent = img.name || '';
    const dateSpan = document.createElement('span');
    const d = new Date(img.createdAt);
    dateSpan.textContent = d.toLocaleString();
    meta.appendChild(nameSpan);
    meta.appendChild(dateSpan);

    item.appendChild(meta);
    gallery.appendChild(item);
  });
}

// ---- Modal viewer ----
function openModalFor(imgObj) {
  const modal = $('#modal');
  $('#modalImg').src = imgObj.dataURL;
  $('#modalImg').alt = imgObj.name || 'Image';
  $('#modalName').textContent = imgObj.name || '';
  $('#modalDate').textContent = new Date(imgObj.createdAt).toLocaleString();
  $('#deleteBtn').dataset.id = imgObj.id;
  $('#downloadBtn').dataset.id = imgObj.id;
  modal.classList.remove('hidden');
  modal.setAttribute('aria-hidden','false');
}
function closeModal() {
  const modal = $('#modal');
  modal.classList.add('hidden');
  modal.setAttribute('aria-hidden','true');
  $('#modalImg').src = '';
}

// ---- Upload handling ----
function handleFiles(files, username) {
  if (!files || files.length === 0) return;
  const maxPerBatch = 10;
  if (files.length > maxPerBatch) {
    showAlert(`Please upload up to ${maxPerBatch} files at once.`);
    return;
  }

  const images = loadImages(username);
  let processed = 0;
  const maxFileSize = 4 * 1024 * 1024; // 4MB per image recommended
  Array.from(files).forEach(file => {
    if (!file.type.startsWith('image/')) {
      showAlert('Skipping non-image file: ' + file.name, 2500);
      processed++;
      return;
    }
    if (file.size > maxFileSize) {
      showAlert(`File too large (>${maxFileSize/1024/1024}MB): ${file.name}`, 4000);
      processed++;
      return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
      const dataURL = e.target.result;
      const item = {
        id: uid(),
        name: file.name,
        dataURL,
        createdAt: new Date().toISOString()
      };
      images.push(item);
      saveImages(username, images);
      processed++;
      if (processed === files.length) {
        renderGallery(username);
        showAlert('Upload complete');
      }
    };
    reader.onerror = function() {
      processed++;
      showAlert('Failed to read: ' + file.name, 2500);
    };
    reader.readAsDataURL(file);
  });
}

// ---- Actions ----
document.addEventListener('DOMContentLoaded', () => {
  const session = getSession();
  const currentUser = session?.username;

  // Elements
  const authForm = $('#authForm');
  const toggleSignup = $('#toggleSignup');
  const fileInput = $('#fileInput');
  const logoutBtn = $('#logoutBtn');
  const clearAllBtn = $('#clearAll');
  const closeModalBtn = $('#closeModal');
  const deleteBtn = $('#deleteBtn');
  const downloadBtn = $('#downloadBtn');

  let signupMode = false;

  // Show auth or gallery based on session
  if (currentUser) {
    $('#user-area')?.classList?.remove('hidden');
    showGalleryFor(currentUser);
  } else {
    showAuth(false);
  }

  toggleSignup.addEventListener('click', () => {
    signupMode = !signupMode;
    showAuth(signupMode);
  });

  authForm.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const username = $('#username').value.trim();
    const password = $('#password').value;
    if (!username || !password) { showAlert('Provide username & password'); return; }

    if (signupMode) {
      const result = signup(username, password);
      if (!result.ok) {
        showAlert(result.message);
        return;
      }
      showAlert('Account created. You are now logged in.');
      setSession(username);
      showGalleryFor(username);
    } else {
      const result = login(username, password);
      if (!result.ok) {
        showAlert(result.message);
        return;
      }
      showAlert('Welcome back!');
      showGalleryFor(username);
    }
  });

  logoutBtn?.addEventListener('click', () => {
    clearSession();
    $('#user-area')?.classList?.add('hidden');
    showAuth(false);
  });

  fileInput?.addEventListener('change', (e) => {
    const session = getSession();
    if (!session?.username) { showAlert('You must be logged in'); return; }
    handleFiles(e.target.files, session.username);
    // reset input so same file can be selected again later
    fileInput.value = '';
  });

  clearAllBtn?.addEventListener('click', () => {
    const session = getSession();
    if (!session?.username) { showAlert('You must be logged in'); return; }
    if (!confirm('Delete ALL images for this user? This action cannot be undone.')) return;
    saveImages(session.username, []);
    renderGallery(session.username);
    showAlert('All images deleted');
  });

  closeModalBtn?.addEventListener('click', closeModal);
  $('#modal')?.addEventListener('click', (ev) => {
    if (ev.target === $('#modal')) closeModal();
  });

  deleteBtn?.addEventListener('click', (ev) => {
    const id = ev.currentTarget.dataset.id;
    const session = getSession();
    if (!session?.username) return;
    let arr = loadImages(session.username);
    arr = arr.filter(i => i.id !== id);
    saveImages(session.username, arr);
    renderGallery(session.username);
    closeModal();
    showAlert('Image deleted');
  });

  downloadBtn?.addEventListener('click', (ev) => {
    const id = ev.currentTarget.dataset.id;
    const session = getSession();
    if (!session?.username) return;
    const arr = loadImages(session.username);
    const item = arr.find(i => i.id === id);
    if (!item) { showAlert('Image not found'); return; }
    // create a link and download
    const a = document.createElement('a');
    a.href = item.dataURL;
    a.download = item.name || 'image.png';
    document.body.appendChild(a);
    a.click();
    a.remove();
  });

});