```markdown
# Personal Image Gallery (front-end demo)

A simple, self-contained personal image gallery that runs entirely in the browser. No backend required — credentials and images are stored in localStorage for local/personal use only.

Features:
- Create a local account (signup) or log in with an existing local account.
- Upload multiple images (converted to base64 data URLs) and view them in a grid.
- Click a thumbnail to open a modal viewer with download and delete actions.
- Images persist in your browser (localStorage) for the signed-in user.
- Simple, minimal design for quick personal use or prototyping.

Important notes:
- This is a front-end simulation for learning and local use. Do NOT use in production.
- localStorage has size limits; storing many or very large images may exceed browser storage quota.
- Passwords are obfuscated with a tiny non-secure hash only to avoid plain storage — still not secure.

Files:
- index.html — main page
- styles.css — styling
- app.js — application logic

How to use:
1. Open `index.html` in your browser (double-click or via a local dev server).
2. Create an account with "Create account" or log in with an account you've already made.
3. Use "Upload Images" to pick photos. They will appear in the gallery and persist across reloads.
4. Click thumbnails to view, download, or delete them.
5. Use "Log out" to switch users.

If you'd like:
- I can add drag-and-drop upload, image resizing before storage, or thumbnails stored separately to reduce storage size.
- I can switch from base64 storage to IndexedDB (better for larger blobs).
- I can add encryption for stored images with a passphrase.

```